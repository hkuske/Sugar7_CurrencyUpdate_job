<?php
/*
  Currency_Update
 */

$manifest = array (
  'acceptable_sugar_versions' => 
  array (
    0 => '7.*.*',
    1 => '8.*.*',
    2 => '9.*.*',
  ),
  'acceptable_sugar_flavors' => 
  array (
    0 => 'PRO',
    1 => 'CORP',
    2 => 'ENT',
    3 => 'ULT',
  ),
  'readme' => '',
  'key' => '',
  'author' => 'kuske',
  'description' => 'Scheduler: Currency_Update',
  'icon' => '',
  'is_uninstallable' => true,
  'name' => 'Currency_Update',
  'published_date' => '2019-05-01 00:00:00',
  'type' => 'module',
  'version' => 9.0.0,
  'remove_tables' => 'false',
);

$installdefs = array (
  'id' => 'Currency_Update',
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/SugarModules/custom/',
      'to' => 'custom/',
    ),
  ),
);
